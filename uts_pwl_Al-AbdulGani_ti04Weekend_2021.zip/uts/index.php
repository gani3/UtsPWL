<?php
session_start();
global $member;

include 'koneksi.php';
include 'Layout/header.php';
include 'Layout/menu.php';
echo "<br/>";
include 'Layout/main.php';
include 'Layout/sidebar.php';
echo "<br/>";
include 'Layout/footer.php';
?>
