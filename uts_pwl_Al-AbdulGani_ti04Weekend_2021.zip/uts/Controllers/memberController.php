<?php
session_start();
  require '../koneksi.php';
  require '../Models/Member.php';

// ambil element yang dikirim
  $username = $_POST['username'];
  $password = $_POST['password'];


// simpam data kedalam array
  $data = [$username,$password];
// eksekusi tombol
  $obj = new Member();

  $rs = $obj->cekLogin($data);
  if (!empty($rs)) {
    $_SESSION['MEMBER'] = $rs;
    header('location:../index.php?hal=dataPegawai');
  }else {
    header('location:../index.php?hal=gagal_login');
  }

// masuk ke halaman verifikasi
  ?>
