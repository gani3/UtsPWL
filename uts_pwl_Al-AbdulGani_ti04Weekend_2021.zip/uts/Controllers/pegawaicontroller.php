<?php
  require '../koneksi.php';
  require '../Models/Pegawai.php';

// ambil element yang dikirim
  $nip = $_POST['nip'];
  $nama = $_POST['nama'];
  $email = $_POST['email'];
  $agama = $_POST['agama'];
  $iddivisi = $_POST['iddivisi'];
  $foto = $_POST['foto'];

// simpam data kedalam array
  $data = [$nip,$nama,$email,$agama,$iddivisi,$foto];
$tombol = $_POST['proses'];
// eksekusi tombol
  $obj = new Pegawai();
switch ($tombol) {
  case 'simpan':
    $obj->formPegawai($data);
  break;

  case 'ubah':
      $data[] = $_POST['idx'];
      $obj->editPegawai($data);
  break;

  case 'hapus':
      $id[] = $_POST['idx'];
      $obj->hapusPegawai($id);
  break;

  default:
    // code...
    break;
}


// masuk ke halaman verifikasi
  header('location:../index.php?hal=dataPegawai');
  ?>
