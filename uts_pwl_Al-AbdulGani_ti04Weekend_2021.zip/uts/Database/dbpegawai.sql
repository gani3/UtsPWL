-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 23 Apr 2021 pada 16.59
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbpegawai`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `Divisi`
--

CREATE TABLE `Divisi` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `Divisi`
--

INSERT INTO `Divisi` (`id`, `nama`) VALUES
(1, 'HRD'),
(2, 'Keuangan'),
(3, 'Operasional'),
(4, 'Marketing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` enum('admin','manager','staff','') NOT NULL,
  `foto` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id`, `fullname`, `username`, `password`, `role`, `foto`) VALUES
(1, 'Al-Abdul Gani', 'Gani', '90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad', 'admin', 'admin.jpg'),
(2, 'Nanda Surya Mustika', 'nanda', '90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad', 'admin', 'admin.jpg'),
(3, 'Amin Makruf', 'amin', '90b9aa7e25f80cf4f64e990b78a9fc5ebd6cecad', 'staff', 'admin.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `Pegawai`
--

CREATE TABLE `Pegawai` (
  `id` int(11) NOT NULL,
  `nip` varchar(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `agama` enum('Islam','Kristen Protestan','Kristen Katolik','Buddha','Hindu','') NOT NULL,
  `iddivisi` int(11) NOT NULL,
  `foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `Pegawai`
--

INSERT INTO `Pegawai` (`id`, `nip`, `nama`, `email`, `agama`, `iddivisi`, `foto`) VALUES
(1, '00001', 'Al-Abdul Gani', 'ganialabdul@gmail.com', 'Islam', 1, 'gambar1.jpg'),
(2, '00002', 'Amin Makruf', 'amin@gmail.com', 'Islam', 2, 'saysa.jpg'),
(3, '00003', 'Nanda Surya Mustika', 'mustika@gmail.com', 'Islam', 3, 'gambar3.jpg'),
(4, '00004', 'Kristina Situmorang', 'kristi@gmail.com', 'Kristen Protestan', 2, 'kriti.jpg'),
(5, '00005', 'Chu Chien li', 'chenli@gmail.com', 'Hindu', 4, 'chien.jpg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `Divisi`
--
ALTER TABLE `Divisi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `Pegawai`
--
ALTER TABLE `Pegawai`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nip` (`nip`),
  ADD KEY `iddivisi` (`iddivisi`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `Divisi`
--
ALTER TABLE `Divisi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `Pegawai`
--
ALTER TABLE `Pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
