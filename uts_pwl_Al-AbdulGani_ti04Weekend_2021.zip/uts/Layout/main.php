<div class="row">
  <div class="col-md-9">
    <?php
      if(!empty($_REQUEST['hal'])) {
        include $_REQUEST['hal'].'.php';
      }else {
        include 'home.php';
      }
     ?>
  </div>
