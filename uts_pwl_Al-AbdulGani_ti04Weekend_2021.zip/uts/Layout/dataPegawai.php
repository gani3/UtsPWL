<?php
require './Models/Pegawai.php';
// membuat object class Pegawai
$obj = new Pegawai();
// panggil method menampilkan data
$rs = $obj->dataPegawai();
 ?>
<h3>Data Pegawai</h3>
<a href="index.php?hal=formPegawai" class="btn btn-success float-right">Tambah data</a>
<br><br>
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nip<th>
      <th scope="col">Nama</th>
      <th scope="col">Divisi</th>
      <th scope="col">Option</th>
    </tr>
  </thead>
  <tbody>
    <?php $no = 1; foreach($rs as $datapegawai) { ?>
      <tr>
        <td><?= $no; ?></td>
        <td><?= $datapegawai['nip']; ?></td>
        <td><?= $datapegawai['nama']; ?></td>
        <td><?= $datapegawai['email']; ?></td>
        <td><?= $datapegawai['divisi']; ?></td>
        <td>
          <form action="./Controllers/pegawaicontroller.php" method="POST">
<?php
    $member = $_SESSION['MEMBER'];
    if (!isset($member)) { ?>
          <a href="index.php?hal=detailPegawai&id=<?= $datapegawai['id']; ?>" class="btn btn-primary">Detail</a>
    <?php } else { ?>
          <a href="index.php?hal=detailPegawai&id=<?= $datapegawai['id']; ?>" class="btn btn-primary">Detail</a>
          <a href="index.php?hal=editPegawai&id=<?= $datapegawai['id']; ?>" class="btn btn-warning">Edit</a>
    <?php if ($member['role']!= 'staff') { ?>
      <input type="hidden" name="idx" value="<?= $datapegawai['id'];?>">
      <button name="proses" value="hapus" class="btn btn-danger" onclick="return confirm('Anda Yakin data dihapus ?')">Hapus</a>
    <?php } else { ?>

    <?php }  ?>

    <?php } ?>
        </form>

        </td>
      </tr>
    <?php $no++;  } ?>
  </tbody>
</table>
