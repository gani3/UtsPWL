<?php
require './Models/Pegawai.php';
$id = $_GET['id'];
$obj = new Pegawai();
$rs = $obj->getPegawai($id);
?>

<h3>From Produk</h3>
<form action="./Controllers/pegawaicontroller.php" method="POST">
  <div class="form-group row">
    <label for="nip" class="col-4 col-form-label">Nip</label>
    <div class="col-8">
      <div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text">
            <i class="fa fa-address-card"></i>
          </div>
        </div>
        <input id="nip" name="nip" value="<?= $rs['nip'] ?>" placeholder="NIP pegawai" type="text" required="required" class="form-control">
      </div>
    </div>
  </div>
  <div class="form-group row">
    <label for="nama" class="col-4 col-form-label">Nama</label>
    <div class="col-8">
      <input id="nama" name="nama" value="<?= $rs['nama'] ?>" placeholder="Nama Pegawai" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="email" class="col-4 col-form-label">Email</label>
    <div class="col-8">
      <input id="email" name="email" value="<?= $rs['email'] ?>" placeholder="Email Pegawai" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label class="col-4">Agama</label>
    <div class="col-8">
      <input id="text" name="agama" value="<?= $rs['agama'] ?>" placeholder="Email Pegawai" type="text" required="required" class="form-control">
    </div>
  </div>
  <div class="form-group row">
    <label for="iddivisi" class="col-4 col-form-label">Divisi</label>
    <div class="col-8">
      <select id="iddivisi" name="iddivisi" class="custom-select">
        <option><?= $rs['divisi'] ?></option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="foto" class="col-4 col-form-label">Foto</label>
    <div class="col-8">
        <img src="./image/<?= $rs['foto'] ?>" class="card-img-bottom" alt="<?= $rs['foto'] ?>">
    </div>
  </div>
  <div class="form-group row">
    <div class="offset-4 col-8">
      <a href="index.php?hal=dataPegawai" class="btn btn-primary">Kembali</a>
    </div>
  </div>
</form>
