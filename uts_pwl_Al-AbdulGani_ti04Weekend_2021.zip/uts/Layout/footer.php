    	<div class="row">
    		<div class="col-md-12">
          <div class="alert alert-primary" role="alert">
            Design by Gani
          </div>
    		</div>
    	</div>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
