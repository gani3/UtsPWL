<?php
  class Pegawai{
    //member 1
    private $koneksi;
    // member 2
    public function __construct()
    {
      global $dbh;
      $this->koneksi = $dbh;
    }

    //member 3 method CRUD

    public function DataPegawai()
    {
      // membuat skrip sql
      $sql = "SELECT Pegawai.*,Divisi.nama as divisi FROM Pegawai INNER JOIN Divisi on Divisi.id = Pegawai.iddivisi";
      // prepare statement
      $ps = $this->koneksi->prepare($sql);
      $ps->execute();
      $rs = $ps->fetchAll();
      return $rs;
    }

    public function dataDivisi()
    {
      $sql = "SELECT * from Divisi";
      $rs = $this->koneksi->query($sql);
      return $rs;
    }

    public function formPegawai($data)
    {
      // membuat skrip sql
      $sql = "INSERT INTO Pegawai(nip,nama,email,agama,iddivisi,foto)
              VALUES (?,?,?,?,?,?)";
      // prepare statement
      $rs = $this->koneksi->prepare($sql);
      $rs->execute($data);
      return $rs;
    }

    public function editPegawai($data)
    {
      // membuat skrip sql
      $sql = "UPDATE Pegawai SET nip=?,nama=?,email=?,agama=?,iddivisi=?,foto=? Where id= ?";
      // prepare statement
      $rs = $this->koneksi->prepare($sql);
      $rs->execute($data);
      // return $rs;
    }

    public function hapusPegawai($id)
    {
      // membuat skrip sql
      $sql = "DELETE FROM Pegawai Where id= ?";
      // prepare statement
      $rs = $this->koneksi->prepare($sql);
      $rs->execute($id);
      return $rs;
    }

    public function getPegawai($id)
    {
      // membuat skrip sql
      $sql = "SELECT Pegawai.*,Divisi.nama as divisi FROM Pegawai INNER JOIN Divisi on Divisi.id = Pegawai.iddivisi WHERE Pegawai.id = ?";
      // prepare statement
      $ps = $this->koneksi->prepare($sql);
      $ps->execute([$id]);
      $rs = $ps->fetch();
      return $rs;
    }

  }

 ?>
