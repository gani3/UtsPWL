<?php
  class Member{
    //member 1
    private $koneksi;
    // member 2
    public function __construct()
    {
      global $dbh;
      $this->koneksi = $dbh;
    }

    //member 3 method CRUD

    public function cekLogin($data)
    {
      // membuat skrip sql
      $sql = "SELECT * FROM member Where username = ? AND password = SHA1(MD5(?))";
      // prepare statement
      $ps = $this->koneksi->prepare($sql);
      $ps->execute($data);
      $rs = $ps->fetch();
      return $rs;
    }


  }

 ?>
